#include "bifrost_nir.h"

#include "nir.h"
#include "nir_builder.h"
#include "nir_search.h"
#include "nir_search_helpers.h"

/* What follows is NIR algebraic transform code for the following 4
 * transforms:
 *    ('iand', 'a@1', 'b@1') => ('bcsel', 'a', 'b', False)
 *    ('ior', 'a@1', 'b@1') => ('bcsel', 'a', 'a', 'b')
 *    ('iand', 'a@1', ('inot', 'b@1')) => ('bcsel', 'b', 0, 'a')
 *    ('ior', 'a@1', ('inot', 'b@1')) => ('bcsel', 'b', 'a', True)
 */


static const nir_search_value_union bifrost_nir_opt_boolean_bitwise_values[] = {
   /* ('iand', 'a@1', 'b@1') => ('bcsel', 'a', 'b', False) */
   { .variable = {
      { nir_search_value_variable, 1 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, 1 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* replace0_0 -> 0 in the cache */
   /* replace0_1 -> 1 in the cache */
   { .constant = {
      { nir_search_value_constant, 1 },
      nir_type_bool, { NIR_FALSE /* False */ },
   } },
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 0, 1, 3 },
      -1,
   } },

   /* ('ior', 'a@1', 'b@1') => ('bcsel', 'a', 'a', 'b') */
   /* search1_0 -> 0 in the cache */
   /* search1_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* replace1_0 -> 0 in the cache */
   /* replace1_1 -> 0 in the cache */
   /* replace1_2 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 0, 0, 1 },
      -1,
   } },

   /* ('iand', 'a@1', ('inot', 'b@1')) => ('bcsel', 'b', 0, 'a') */
   /* search2_0 -> 0 in the cache */
   /* search2_1_0 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_inot,
      -1, 0,
      { 1 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 0, 7 },
      -1,
   } },

   /* replace2_0 -> 1 in the cache */
   { .constant = {
      { nir_search_value_constant, 1 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   /* replace2_2 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 1, 9, 0 },
      -1,
   } },

   /* ('ior', 'a@1', ('inot', 'b@1')) => ('bcsel', 'b', 'a', True) */
   /* search3_0 -> 0 in the cache */
   /* search3_1_0 -> 1 in the cache */
   /* search3_1 -> 7 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 0, 7 },
      -1,
   } },

   /* replace3_0 -> 1 in the cache */
   /* replace3_1 -> 0 in the cache */
   { .constant = {
      { nir_search_value_constant, 1 },
      nir_type_bool, { NIR_TRUE /* True */ },
   } },
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 1, 0, 12 },
      -1,
   } },

};



static const struct transform bifrost_nir_opt_boolean_bitwise_transforms[] = {
   { ~0, ~0, ~0 }, /* Sentinel */

   { 2, 4, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 5, 6, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 2, 4, 0 },
   { 8, 10, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 5, 6, 0 },
   { 11, 13, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

};

static const struct per_op_table bifrost_nir_opt_boolean_bitwise_pass_op_table[nir_num_search_ops] = {
   [nir_op_iand] = {
      .filter = (const uint16_t []) {
         0,
         0,
         0,
         0,
         1,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         2,
         5,
         5,
         5,
      },
   },
   [nir_op_ior] = {
      .filter = (const uint16_t []) {
         0,
         0,
         0,
         0,
         1,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         3,
         6,
         6,
         6,
      },
   },
   [nir_op_inot] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         4,
      },
   },
};

/* Mapping from state index to offset in transforms (0 being no transforms) */
static const uint16_t bifrost_nir_opt_boolean_bitwise_transform_offsets[] = {
   0,
   0,
   1,
   3,
   0,
   5,
   8,
};

static const nir_algebraic_table bifrost_nir_opt_boolean_bitwise_table = {
   .transforms = bifrost_nir_opt_boolean_bitwise_transforms,
   .transform_offsets = bifrost_nir_opt_boolean_bitwise_transform_offsets,
   .pass_op_table = bifrost_nir_opt_boolean_bitwise_pass_op_table,
   .values = bifrost_nir_opt_boolean_bitwise_values,
   .expression_cond = NULL,
   .variable_cond = NULL,
};

bool
bifrost_nir_opt_boolean_bitwise(
   nir_shader *shader
) {
   bool progress = false;
   bool condition_flags[1];
   const nir_shader_compiler_options *options = shader->options;
   const shader_info *info = &shader->info;
   (void) options;
   (void) info;

   STATIC_ASSERT(14 == ARRAY_SIZE(bifrost_nir_opt_boolean_bitwise_values));
   condition_flags[0] = true;

   nir_foreach_function_impl(impl, shader) {
     progress |= nir_algebraic_impl(impl, condition_flags, &bifrost_nir_opt_boolean_bitwise_table);
   }

   return progress;
}


#include "nir.h"
#include "nir_builder.h"
#include "nir_search.h"
#include "nir_search_helpers.h"

/* What follows is NIR algebraic transform code for the following 130
 * transforms:
 *    ('fmul', 'a', 2.0) => ('fadd', 'a', 'a')
 *    ('fmin', ('fmax', 'a', -1.0), 1.0) => ('fsat_signed', 'a')
 *    ('fmax', ('fmin', 'a', 1.0), -1.0) => ('fsat_signed', 'a')
 *    ('fmax', 'a', 0.0) => ('fclamp_pos', 'a')
 *    ('bcsel_pan', 'b@32', ('iadd', 'a@32', 1), 'a') => ('iadd', 'a', ('b2i32', 'b'))
 *    ('imin@8', 'a', 'b') => ('bcsel_pan', ('ilt_pan', 'a', 'b'), 'a', 'b')
 *    ('imax@8', 'a', 'b') => ('bcsel_pan', ('ilt_pan', 'a', 'b'), 'b', 'a')
 *    ('umin@8', 'a', 'b') => ('bcsel_pan', ('ult_pan', 'a', 'b'), 'a', 'b')
 *    ('umax@8', 'a', 'b') => ('bcsel_pan', ('ult_pan', 'a', 'b'), 'b', 'a')
 *    ('f2i8', 'a') => ('u2u8', ('f2i16', 'a'))
 *    ('f2u8', 'a') => ('u2u8', ('f2u16', 'a'))
 *    ('unpack_64_2x32', 'a') => ('vec2', ('unpack_64_2x32_split_x', 'a'), ('unpack_64_2x32_split_y', 'a'))
 *    ('i2f32', 'a@8') => ('i2f32', ('i2i32', 'a'))
 *    ('i2f32', 'a@16') => ('i2f32', ('i2i32', 'a'))
 *    ('u2f32', 'a@8') => ('u2f32', ('u2u32', 'a'))
 *    ('u2f32', 'a@16') => ('u2f32', ('u2u32', 'a'))
 *    ('i2f16', 'a') => ('f2f16', ('i2f32', ('i2i32', 'a')))
 *    ('u2f16', 'a') => ('f2f16', ('u2f32', ('u2u32', 'a')))
 *    ('i2f16', 'a@32') => ('f2f16', ('i2f32', 'a'))
 *    ('u2f16', 'a@32') => ('f2f16', ('u2f32', 'a'))
 *    ('f2i16', 'a@16') => ('f2i16', ('f2f32', 'a'))
 *    ('f2u16', 'a@16') => ('f2u16', ('f2f32', 'a'))
 *    ('pack_half_2x16_split', 'a', 'b') => ('pack_32_2x16_split', ('f2f16', 'a'), ('f2f16', 'b'))
 *    ('f2i32', 'a@16') => ('f2i32', ('f2f32', 'a'))
 *    ('f2u32', 'a@16') => ('f2u32', ('f2f32', 'a'))
 *    ('f2u16', 'a') => ('u2u16', ('f2u32', 'a'))
 *    ('f2i16', 'a') => ('u2u16', ('f2i32', 'a'))
 *    ('pack_uvec2_to_uint', 'a') => ('pack_32_2x16', ('u2u16', 'a'))
 *    ('pack_uvec4_to_uint', 'a') => ('pack_32_4x8', ('u2u8', 'a'))
 *    ('ffract', 'a') => ('fadd', 'a', ('fneg', ('ffloor', 'a')))
 *    ('i2i8', 'a@8') => a
 *    ('i2i16', 'a@16') => a
 *    ('i2i32', 'a@32') => a
 *    ('ilt_pan@8', 'a', 'b') => ('u2u8', ('ilt_pan', ('i2i16', 'a'), ('i2i16', 'b')))
 *    ('ige_pan@8', 'a', 'b') => ('u2u8', ('ige_pan', ('i2i16', 'a'), ('i2i16', 'b')))
 *    ('ieq_pan@8', 'a', 'b') => ('u2u8', ('ieq_pan', ('i2i16', 'a'), ('i2i16', 'b')))
 *    ('ine_pan@8', 'a', 'b') => ('u2u8', ('ine_pan', ('i2i16', 'a'), ('i2i16', 'b')))
 *    ('ult_pan@8', 'a', 'b') => ('u2u8', ('ult_pan', ('u2u16', 'a'), ('u2u16', 'b')))
 *    ('uge_pan@8', 'a', 'b') => ('u2u8', ('uge_pan', ('u2u16', 'a'), ('u2u16', 'b')))
 *    ('b2f16', ('inot', 'a@8')) => ('bcsel_pan', ('i2i16', 'a'), 0.0, 1.0)
 *    ('b2f16', 'a@8') => ('bcsel_pan', ('i2i16', 'a'), 1.0, 0.0)
 *    ('b2f16', ('inot', 'a@16')) => ('bcsel_pan', 'a', 0.0, 1.0)
 *    ('b2f16', 'a@16') => ('bcsel_pan', 'a', 1.0, 0.0)
 *    ('b2f16', ('inot', 'a@32')) => ('bcsel_pan', ('u2u16', 'a'), 0.0, 1.0)
 *    ('b2f16', 'a@32') => ('bcsel_pan', ('u2u16', 'a'), 1.0, 0.0)
 *    ('b2f16', ('inot', 'a@64')) => ('bcsel_pan', ('u2u16', 'a'), 0.0, 1.0)
 *    ('b2f16', 'a@64') => ('bcsel_pan', ('u2u16', 'a'), 1.0, 0.0)
 *    ('b2f32', ('inot', 'a@8')) => ('bcsel_pan', ('i2i32', 'a'), 0.0, 1.0)
 *    ('b2f32', 'a@8') => ('bcsel_pan', ('i2i32', 'a'), 1.0, 0.0)
 *    ('b2f32', ('inot', 'a@16')) => ('bcsel_pan', ('i2i32', 'a'), 0.0, 1.0)
 *    ('b2f32', 'a@16') => ('bcsel_pan', ('i2i32', 'a'), 1.0, 0.0)
 *    ('b2f32', ('inot', 'a@32')) => ('bcsel_pan', 'a', 0.0, 1.0)
 *    ('b2f32', 'a@32') => ('bcsel_pan', 'a', 1.0, 0.0)
 *    ('b2f32', ('inot', 'a@64')) => ('bcsel_pan', ('u2u32', 'a'), 0.0, 1.0)
 *    ('b2f32', 'a@64') => ('bcsel_pan', ('u2u32', 'a'), 1.0, 0.0)
 *    ('b2i8', ('inot', 'a@8')) => ('bcsel_pan', 'a', 0, 1)
 *    ('b2i8', 'a@8') => ('bcsel_pan', 'a', 1, 0)
 *    ('b2i8', ('inot', 'a@16')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1)
 *    ('b2i8', 'a@16') => ('bcsel_pan', ('u2u8', 'a'), 1, 0)
 *    ('b2i8', ('inot', 'a@32')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1)
 *    ('b2i8', 'a@32') => ('bcsel_pan', ('u2u8', 'a'), 1, 0)
 *    ('b2i8', ('inot', 'a@64')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1)
 *    ('b2i8', 'a@64') => ('bcsel_pan', ('u2u8', 'a'), 1, 0)
 *    ('b2i16', ('inot', 'a@8')) => ('bcsel_pan', ('i2i16', 'a'), 0, 1)
 *    ('b2i16', 'a@8') => ('bcsel_pan', ('i2i16', 'a'), 1, 0)
 *    ('b2i16', ('inot', 'a@16')) => ('bcsel_pan', 'a', 0, 1)
 *    ('b2i16', 'a@16') => ('bcsel_pan', 'a', 1, 0)
 *    ('b2i16', ('inot', 'a@32')) => ('bcsel_pan', ('u2u16', 'a'), 0, 1)
 *    ('b2i16', 'a@32') => ('bcsel_pan', ('u2u16', 'a'), 1, 0)
 *    ('b2i16', ('inot', 'a@64')) => ('bcsel_pan', ('u2u16', 'a'), 0, 1)
 *    ('b2i16', 'a@64') => ('bcsel_pan', ('u2u16', 'a'), 1, 0)
 *    ('b2i32', ('inot', 'a@8')) => ('bcsel_pan', ('i2i32', 'a'), 0, 1)
 *    ('b2i32', 'a@8') => ('bcsel_pan', ('i2i32', 'a'), 1, 0)
 *    ('b2i32', ('inot', 'a@16')) => ('bcsel_pan', ('i2i32', 'a'), 0, 1)
 *    ('b2i32', 'a@16') => ('bcsel_pan', ('i2i32', 'a'), 1, 0)
 *    ('b2i32', ('inot', 'a@32')) => ('bcsel_pan', 'a', 0, 1)
 *    ('b2i32', 'a@32') => ('bcsel_pan', 'a', 1, 0)
 *    ('b2i32', ('inot', 'a@64')) => ('bcsel_pan', ('u2u32', 'a'), 0, 1)
 *    ('b2i32', 'a@64') => ('bcsel_pan', ('u2u32', 'a'), 1, 0)
 *    ('b2i64', ('inot', 'a@8')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1)
 *    ('b2i64', 'a@8') => ('bcsel_pan', ('i2i64', 'a'), 1, 0)
 *    ('b2i64', ('inot', 'a@16')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1)
 *    ('b2i64', 'a@16') => ('bcsel_pan', ('i2i64', 'a'), 1, 0)
 *    ('b2i64', ('inot', 'a@32')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1)
 *    ('b2i64', 'a@32') => ('bcsel_pan', ('i2i64', 'a'), 1, 0)
 *    ('b2i64', ('inot', 'a@64')) => ('bcsel_pan', 'a', 0, 1)
 *    ('b2i64', 'a@64') => ('bcsel_pan', 'a', 1, 0)
 *    ('iand', ('ishl(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('lshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ishl', 'b', 'c'), 'd'))
 *    ('iand', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_and_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishl', ('iand', 'a', '#b'), '#c') => ('lshift_and_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c'))
 *    ('ior', ('ishl(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('lshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ishl', 'b', 'c'), 'd'))
 *    ('ior', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_or_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishl', ('ior', 'a', '#b'), '#c') => ('lshift_or_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c'))
 *    ('ixor', ('ishl(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('lshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ishl', 'b', 'c'), 'd'))
 *    ('ixor', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_xor_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishl', ('ixor', 'a', '#b'), '#c') => ('lshift_xor_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c'))
 *    ('iand', ('ushr(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('rshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ushr', 'b', 'c'), 'd'))
 *    ('iand', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_and_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ushr', ('iand', 'a', '#b'), '#c') => ('rshift_and_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c'))
 *    ('ior', ('ushr(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('rshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ushr', 'b', 'c'), 'd'))
 *    ('ior', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_or_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ushr', ('ior', 'a', '#b'), '#c') => ('rshift_or_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c'))
 *    ('ixor', ('ushr(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('rshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ushr', 'b', 'c'), 'd'))
 *    ('ixor', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_xor_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ushr', ('ixor', 'a', '#b'), '#c') => ('rshift_xor_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c'))
 *    ('iand', ('ishr(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('arshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ishr', 'b', 'c'), 'd'))
 *    ('iand', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_and_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishr', ('iand', 'a', '#b'), '#c') => ('arshift_and_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c'))
 *    ('ior', ('ishr(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('arshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ishr', 'b', 'c'), 'd'))
 *    ('ior', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_or_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishr', ('ior', 'a', '#b'), '#c') => ('arshift_or_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c'))
 *    ('ixor', ('ishr(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('arshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ishr', 'b', 'c'), 'd'))
 *    ('ixor', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_xor_pan', 'a', ('u2u8', 'b'), 'c')
 *    ('ishr', ('ixor', 'a', '#b'), '#c') => ('arshift_xor_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c'))
 *    ('iand', 'a', 'b') => ('lshift_and_pan', 'a', 0, 'b')
 *    ('ior', 'a', 'b') => ('lshift_or_pan', 'a', 0, 'b')
 *    ('ixor', 'a', 'b') => ('lshift_xor_pan', 'a', 0, 'b')
 *    ('ishl', 'a', 'b') => ('lshift_or_pan', 'a', ('u2u8', 'b'), 0)
 *    ('ushr', 'a', 'b') => ('rshift_or_pan', 'a', ('u2u8', 'b'), 0)
 *    ('ishr', 'a', 'b') => ('arshift_or_pan', 'a', ('u2u8', 'b'), 0)
 *    ('urol', 'a', 'b') => ('lrot_or_pan', 'a', ('u2u8', 'b'), 0)
 *    ('uror', 'a', 'b') => ('rrot_or_pan', 'a', ('u2u8', 'b'), 0)
 *    ('imul_high', 'a@8', 'b@8') => ('u2u8', ('extract_u8', ('imul', ('i2i16', 'a'), ('i2i16', 'b')), 1))
 *    ('umul_high', 'a@8', 'b@8') => ('u2u8', ('extract_u8', ('imul', ('u2u16', 'a'), ('u2u16', 'b')), 1))
 *    ('imul_high', 'a@16', 'b@16') => ('unpack_32_2x16_split_y', ('imul', ('i2i32', 'a'), ('i2i32', 'b')))
 *    ('umul_high', 'a@16', 'b@16') => ('unpack_32_2x16_split_y', ('imul', ('u2u32', 'a'), ('u2u32', 'b')))
 *    ('imul_high', 'a@32', 'b@32') => ('unpack_64_2x32_split_y', ('imul_2x32_64', 'a', 'b'))
 *    ('umul_high', 'a@32', 'b@32') => ('unpack_64_2x32_split_y', ('umul_2x32_64', 'a', 'b'))
 *    ('fpow', 'a@16', 'b@16') => ('fexp2', ('fmul', ('flog2', 'a'), 'b'))
 *    ('ldexp', 'a@16', 'b') => ('ldexp16_pan', 'a', ('u2u16', ('imin', ('imax', 'b', -127), 127)))
 */


static const nir_search_value_union bifrost_nir_lower_algebraic_late_values[] = {
   /* ('fmul', 'a', 2.0) => ('fadd', 'a', 'a') */
   { .variable = {
      { nir_search_value_variable, -1 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .constant = {
      { nir_search_value_constant, -1 },
      nir_type_float, { 0x4000000000000000ull /* 2.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmul,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* replace4_0 -> 0 in the cache */
   /* replace4_1 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fadd,
      -1, 0,
      { 0, 0 },
      -1,
   } },

   /* ('fmin', ('fmax', 'a', -1.0), 1.0) => ('fsat_signed', 'a') */
   /* search5_0_0 -> 0 in the cache */
   { .constant = {
      { nir_search_value_constant, -1 },
      nir_type_float, { 0xbff0000000000000ull /* -1.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmax,
      1, 1,
      { 0, 4 },
      -1,
   } },
   { .constant = {
      { nir_search_value_constant, -1 },
      nir_type_float, { 0x3ff0000000000000ull /* 1.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmin,
      0, 2,
      { 5, 6 },
      -1,
   } },

   /* replace5_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fsat_signed,
      -1, 0,
      { 0 },
      -1,
   } },

   /* ('fmax', ('fmin', 'a', 1.0), -1.0) => ('fsat_signed', 'a') */
   /* search6_0_0 -> 0 in the cache */
   /* search6_0_1 -> 6 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmin,
      1, 1,
      { 0, 6 },
      -1,
   } },
   /* search6_1 -> 4 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmax,
      0, 2,
      { 9, 4 },
      -1,
   } },

   /* replace6_0 -> 0 in the cache */
   /* replace6 -> 8 in the cache */

   /* ('fmax', 'a', 0.0) => ('fclamp_pos', 'a') */
   /* search7_0 -> 0 in the cache */
   { .constant = {
      { nir_search_value_constant, -1 },
      nir_type_float, { 0x0ull /* 0.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fmax,
      0, 1,
      { 0, 11 },
      -1,
   } },

   /* replace7_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fclamp_pos,
      -1, 0,
      { 0 },
      -1,
   } },

   /* ('bcsel_pan', 'b@32', ('iadd', 'a@32', 1), 'a') => ('iadd', 'a', ('b2i32', 'b')) */
   { .variable = {
      { nir_search_value_variable, 32 },
      0, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, 32 },
      1, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_int, { 0x1ull /* 1 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_iadd,
      0, 1,
      { 15, 16 },
      -1,
   } },
   /* search8_2 -> 15 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel_pan,
      -1, 1,
      { 14, 17, 15 },
      -1,
   } },

   /* replace8_0 -> 15 in the cache */
   /* replace8_1_0 -> 14 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 14 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iadd,
      0, 1,
      { 15, 19 },
      -1,
   } },

   /* ('imin@8', 'a', 'b') => ('bcsel_pan', ('ilt_pan', 'a', 'b'), 'a', 'b') */
   { .variable = {
      { nir_search_value_variable, 8 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, 8 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imin,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace9_0_0 -> 21 in the cache */
   /* replace9_0_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ilt_pan,
      -1, 0,
      { 21, 22 },
      -1,
   } },
   /* replace9_1 -> 21 in the cache */
   /* replace9_2 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 24, 21, 22 },
      -1,
   } },

   /* ('imax@8', 'a', 'b') => ('bcsel_pan', ('ilt_pan', 'a', 'b'), 'b', 'a') */
   /* search10_0 -> 21 in the cache */
   /* search10_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imax,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace10_0_0 -> 21 in the cache */
   /* replace10_0_1 -> 22 in the cache */
   /* replace10_0 -> 24 in the cache */
   /* replace10_1 -> 22 in the cache */
   /* replace10_2 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 24, 22, 21 },
      -1,
   } },

   /* ('umin@8', 'a', 'b') => ('bcsel_pan', ('ult_pan', 'a', 'b'), 'a', 'b') */
   /* search11_0 -> 21 in the cache */
   /* search11_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umin,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace11_0_0 -> 21 in the cache */
   /* replace11_0_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ult_pan,
      -1, 0,
      { 21, 22 },
      -1,
   } },
   /* replace11_1 -> 21 in the cache */
   /* replace11_2 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 29, 21, 22 },
      -1,
   } },

   /* ('umax@8', 'a', 'b') => ('bcsel_pan', ('ult_pan', 'a', 'b'), 'b', 'a') */
   /* search12_0 -> 21 in the cache */
   /* search12_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umax,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace12_0_0 -> 21 in the cache */
   /* replace12_0_1 -> 22 in the cache */
   /* replace12_0 -> 29 in the cache */
   /* replace12_1 -> 22 in the cache */
   /* replace12_2 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 29, 22, 21 },
      -1,
   } },

   /* ('f2i8', 'a') => ('u2u8', ('f2i16', 'a')) */
   /* search13_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i8,
      -1, 0,
      { 0 },
      -1,
   } },

   /* replace13_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i16,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 34 },
      -1,
   } },

   /* ('f2u8', 'a') => ('u2u8', ('f2u16', 'a')) */
   /* search14_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u8,
      -1, 0,
      { 0 },
      -1,
   } },

   /* replace14_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u16,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 37 },
      -1,
   } },

   /* ('unpack_64_2x32', 'a') => ('vec2', ('unpack_64_2x32_split_x', 'a'), ('unpack_64_2x32_split_y', 'a')) */
   { .variable = {
      { nir_search_value_variable, 64 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_64_2x32,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace15_0_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_64_2x32_split_x,
      -1, 0,
      { 39 },
      -1,
   } },
   /* replace15_1_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_64_2x32_split_y,
      -1, 0,
      { 39 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_vec2,
      -1, 0,
      { 41, 42 },
      -1,
   } },

   /* ('i2f32', 'a@8') => ('i2f32', ('i2i32', 'a')) */
   /* search16_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace16_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i32,
      -1, 0,
      { 21 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 45 },
      -1,
   } },

   /* ('i2f32', 'a@16') => ('i2f32', ('i2i32', 'a')) */
   { .variable = {
      { nir_search_value_variable, 16 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace17_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i32,
      -1, 0,
      { 47 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 49 },
      -1,
   } },

   /* ('u2f32', 'a@8') => ('u2f32', ('u2u32', 'a')) */
   /* search18_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace18_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u32,
      -1, 0,
      { 21 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 52 },
      -1,
   } },

   /* ('u2f32', 'a@16') => ('u2f32', ('u2u32', 'a')) */
   /* search19_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace19_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u32,
      -1, 0,
      { 47 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 55 },
      -1,
   } },

   /* ('i2f16', 'a') => ('f2f16', ('i2f32', ('i2i32', 'a'))) */
   /* search20_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f16,
      -1, 0,
      { 0 },
      -1,
   } },

   /* replace20_0_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i32,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 58 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 59 },
      -1,
   } },

   /* ('u2f16', 'a') => ('f2f16', ('u2f32', ('u2u32', 'a'))) */
   /* search21_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f16,
      -1, 0,
      { 0 },
      -1,
   } },

   /* replace21_0_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u32,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 62 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 63 },
      -1,
   } },

   /* ('i2f16', 'a@32') => ('f2f16', ('i2f32', 'a')) */
   { .variable = {
      { nir_search_value_variable, 32 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f16,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace22_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2f32,
      -1, 0,
      { 65 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 67 },
      -1,
   } },

   /* ('u2f16', 'a@32') => ('f2f16', ('u2f32', 'a')) */
   /* search23_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f16,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace23_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2f32,
      -1, 0,
      { 65 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 70 },
      -1,
   } },

   /* ('f2i16', 'a@16') => ('f2i16', ('f2f32', 'a')) */
   /* search24_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i16,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace24_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f32,
      -1, 0,
      { 47 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i16,
      -1, 0,
      { 73 },
      -1,
   } },

   /* ('f2u16', 'a@16') => ('f2u16', ('f2f32', 'a')) */
   /* search25_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u16,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace25_0_0 -> 47 in the cache */
   /* replace25_0 -> 73 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u16,
      -1, 0,
      { 73 },
      -1,
   } },

   /* ('pack_half_2x16_split', 'a', 'b') => ('pack_32_2x16_split', ('f2f16', 'a'), ('f2f16', 'b')) */
   /* search26_0 -> 65 in the cache */
   { .variable = {
      { nir_search_value_variable, 32 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_half_2x16_split,
      -1, 0,
      { 65, 77 },
      -1,
   } },

   /* replace26_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 65 },
      -1,
   } },
   /* replace26_1_0 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2f16,
      -1, 0,
      { 77 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_32_2x16_split,
      -1, 0,
      { 79, 80 },
      -1,
   } },

   /* ('f2i32', 'a@16') => ('f2i32', ('f2f32', 'a')) */
   /* search27_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace27_0_0 -> 47 in the cache */
   /* replace27_0 -> 73 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i32,
      -1, 0,
      { 73 },
      -1,
   } },

   /* ('f2u32', 'a@16') => ('f2u32', ('f2f32', 'a')) */
   /* search28_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace28_0_0 -> 47 in the cache */
   /* replace28_0 -> 73 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u32,
      -1, 0,
      { 73 },
      -1,
   } },

   /* ('f2u16', 'a') => ('u2u16', ('f2u32', 'a')) */
   /* search29_0 -> 0 in the cache */
   /* search29 -> 37 in the cache */

   /* replace29_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2u32,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 86 },
      -1,
   } },

   /* ('f2i16', 'a') => ('u2u16', ('f2i32', 'a')) */
   /* search30_0 -> 0 in the cache */
   /* search30 -> 34 in the cache */

   /* replace30_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_f2i32,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 88 },
      -1,
   } },

   /* ('pack_uvec2_to_uint', 'a') => ('pack_32_2x16', ('u2u16', 'a')) */
   /* search31_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_uvec2_to_uint,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace31_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 65 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_32_2x16,
      -1, 0,
      { 91 },
      -1,
   } },

   /* ('pack_uvec4_to_uint', 'a') => ('pack_32_4x8', ('u2u8', 'a')) */
   /* search32_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_uvec4_to_uint,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace32_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 65 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_pack_32_4x8,
      -1, 0,
      { 94 },
      -1,
   } },

   /* ('ffract', 'a') => ('fadd', 'a', ('fneg', ('ffloor', 'a'))) */
   /* search33_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ffract,
      -1, 0,
      { 0 },
      -1,
   } },

   /* replace33_0 -> 0 in the cache */
   /* replace33_1_0_0 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ffloor,
      -1, 0,
      { 0 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fneg,
      -1, 0,
      { 97 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fadd,
      0, 1,
      { 0, 98 },
      -1,
   } },

   /* ('i2i8', 'a@8') => a */
   /* search34_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i8,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace34 -> 21 in the cache */

   /* ('i2i16', 'a@16') => a */
   /* search35_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i16,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace35 -> 47 in the cache */

   /* ('i2i32', 'a@32') => a */
   /* search36_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i32,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace36 -> 65 in the cache */

   /* ('ilt_pan@8', 'a', 'b') => ('u2u8', ('ilt_pan', ('i2i16', 'a'), ('i2i16', 'b'))) */
   /* search37_0 -> 21 in the cache */
   /* search37_1 -> 22 in the cache */
   /* search37 -> 24 in the cache */

   /* replace37_0_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i16,
      -1, 0,
      { 21 },
      -1,
   } },
   /* replace37_0_1_0 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i16,
      -1, 0,
      { 22 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ilt_pan,
      -1, 0,
      { 103, 104 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 105 },
      -1,
   } },

   /* ('ige_pan@8', 'a', 'b') => ('u2u8', ('ige_pan', ('i2i16', 'a'), ('i2i16', 'b'))) */
   /* search38_0 -> 21 in the cache */
   /* search38_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ige_pan,
      -1, 0,
      { 21, 22 },
      -1,
   } },

   /* replace38_0_0_0 -> 21 in the cache */
   /* replace38_0_0 -> 103 in the cache */
   /* replace38_0_1_0 -> 22 in the cache */
   /* replace38_0_1 -> 104 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ige_pan,
      -1, 0,
      { 103, 104 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 108 },
      -1,
   } },

   /* ('ieq_pan@8', 'a', 'b') => ('u2u8', ('ieq_pan', ('i2i16', 'a'), ('i2i16', 'b'))) */
   /* search39_0 -> 21 in the cache */
   /* search39_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ieq_pan,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace39_0_0_0 -> 21 in the cache */
   /* replace39_0_0 -> 103 in the cache */
   /* replace39_0_1_0 -> 22 in the cache */
   /* replace39_0_1 -> 104 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ieq_pan,
      0, 1,
      { 103, 104 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 1,
      { 111 },
      -1,
   } },

   /* ('ine_pan@8', 'a', 'b') => ('u2u8', ('ine_pan', ('i2i16', 'a'), ('i2i16', 'b'))) */
   /* search40_0 -> 21 in the cache */
   /* search40_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ine_pan,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace40_0_0_0 -> 21 in the cache */
   /* replace40_0_0 -> 103 in the cache */
   /* replace40_0_1_0 -> 22 in the cache */
   /* replace40_0_1 -> 104 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ine_pan,
      0, 1,
      { 103, 104 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 1,
      { 114 },
      -1,
   } },

   /* ('ult_pan@8', 'a', 'b') => ('u2u8', ('ult_pan', ('u2u16', 'a'), ('u2u16', 'b'))) */
   /* search41_0 -> 21 in the cache */
   /* search41_1 -> 22 in the cache */
   /* search41 -> 29 in the cache */

   /* replace41_0_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 21 },
      -1,
   } },
   /* replace41_0_1_0 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 22 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ult_pan,
      -1, 0,
      { 116, 117 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 118 },
      -1,
   } },

   /* ('uge_pan@8', 'a', 'b') => ('u2u8', ('uge_pan', ('u2u16', 'a'), ('u2u16', 'b'))) */
   /* search42_0 -> 21 in the cache */
   /* search42_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_uge_pan,
      -1, 0,
      { 21, 22 },
      -1,
   } },

   /* replace42_0_0_0 -> 21 in the cache */
   /* replace42_0_0 -> 116 in the cache */
   /* replace42_0_1_0 -> 22 in the cache */
   /* replace42_0_1 -> 117 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_uge_pan,
      -1, 0,
      { 116, 117 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 121 },
      -1,
   } },

   /* ('b2f16', ('inot', 'a@8')) => ('bcsel_pan', ('i2i16', 'a'), 0.0, 1.0) */
   /* search43_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_inot,
      -1, 0,
      { 21 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace43_0_0 -> 21 in the cache */
   /* replace43_0 -> 103 in the cache */
   { .constant = {
      { nir_search_value_constant, 16 },
      nir_type_float, { 0x0ull /* 0.0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 16 },
      nir_type_float, { 0x3ff0000000000000ull /* 1.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 103, 125, 126 },
      -1,
   } },

   /* ('b2f16', 'a@8') => ('bcsel_pan', ('i2i16', 'a'), 1.0, 0.0) */
   /* search44_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace44_0_0 -> 21 in the cache */
   /* replace44_0 -> 103 in the cache */
   /* replace44_1 -> 126 in the cache */
   /* replace44_2 -> 125 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 103, 126, 125 },
      -1,
   } },

   /* ('b2f16', ('inot', 'a@16')) => ('bcsel_pan', 'a', 0.0, 1.0) */
   /* search45_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_inot,
      -1, 0,
      { 47 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace45_0 -> 47 in the cache */
   /* replace45_1 -> 125 in the cache */
   /* replace45_2 -> 126 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 47, 125, 126 },
      -1,
   } },

   /* ('b2f16', 'a@16') => ('bcsel_pan', 'a', 1.0, 0.0) */
   /* search46_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace46_0 -> 47 in the cache */
   /* replace46_1 -> 126 in the cache */
   /* replace46_2 -> 125 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 47, 126, 125 },
      -1,
   } },

   /* ('b2f16', ('inot', 'a@32')) => ('bcsel_pan', ('u2u16', 'a'), 0.0, 1.0) */
   /* search47_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_inot,
      -1, 0,
      { 65 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace47_0_0 -> 65 in the cache */
   /* replace47_0 -> 91 in the cache */
   /* replace47_1 -> 125 in the cache */
   /* replace47_2 -> 126 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 91, 125, 126 },
      -1,
   } },

   /* ('b2f16', 'a@32') => ('bcsel_pan', ('u2u16', 'a'), 1.0, 0.0) */
   /* search48_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace48_0_0 -> 65 in the cache */
   /* replace48_0 -> 91 in the cache */
   /* replace48_1 -> 126 in the cache */
   /* replace48_2 -> 125 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 91, 126, 125 },
      -1,
   } },

   /* ('b2f16', ('inot', 'a@64')) => ('bcsel_pan', ('u2u16', 'a'), 0.0, 1.0) */
   /* search49_0_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_inot,
      -1, 0,
      { 39 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace49_0_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 0,
      { 39 },
      -1,
   } },
   /* replace49_1 -> 125 in the cache */
   /* replace49_2 -> 126 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 142, 125, 126 },
      -1,
   } },

   /* ('b2f16', 'a@64') => ('bcsel_pan', ('u2u16', 'a'), 1.0, 0.0) */
   /* search50_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f16,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace50_0_0 -> 39 in the cache */
   /* replace50_0 -> 142 in the cache */
   /* replace50_1 -> 126 in the cache */
   /* replace50_2 -> 125 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 142, 126, 125 },
      -1,
   } },

   /* ('b2f32', ('inot', 'a@8')) => ('bcsel_pan', ('i2i32', 'a'), 0.0, 1.0) */
   /* search51_0_0 -> 21 in the cache */
   /* search51_0 -> 123 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace51_0_0 -> 21 in the cache */
   /* replace51_0 -> 45 in the cache */
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_float, { 0x0ull /* 0.0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_float, { 0x3ff0000000000000ull /* 1.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 45, 147, 148 },
      -1,
   } },

   /* ('b2f32', 'a@8') => ('bcsel_pan', ('i2i32', 'a'), 1.0, 0.0) */
   /* search52_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace52_0_0 -> 21 in the cache */
   /* replace52_0 -> 45 in the cache */
   /* replace52_1 -> 148 in the cache */
   /* replace52_2 -> 147 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 45, 148, 147 },
      -1,
   } },

   /* ('b2f32', ('inot', 'a@16')) => ('bcsel_pan', ('i2i32', 'a'), 0.0, 1.0) */
   /* search53_0_0 -> 47 in the cache */
   /* search53_0 -> 130 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace53_0_0 -> 47 in the cache */
   /* replace53_0 -> 49 in the cache */
   /* replace53_1 -> 147 in the cache */
   /* replace53_2 -> 148 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 49, 147, 148 },
      -1,
   } },

   /* ('b2f32', 'a@16') => ('bcsel_pan', ('i2i32', 'a'), 1.0, 0.0) */
   /* search54_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace54_0_0 -> 47 in the cache */
   /* replace54_0 -> 49 in the cache */
   /* replace54_1 -> 148 in the cache */
   /* replace54_2 -> 147 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 49, 148, 147 },
      -1,
   } },

   /* ('b2f32', ('inot', 'a@32')) => ('bcsel_pan', 'a', 0.0, 1.0) */
   /* search55_0_0 -> 65 in the cache */
   /* search55_0 -> 135 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace55_0 -> 65 in the cache */
   /* replace55_1 -> 147 in the cache */
   /* replace55_2 -> 148 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 65, 147, 148 },
      -1,
   } },

   /* ('b2f32', 'a@32') => ('bcsel_pan', 'a', 1.0, 0.0) */
   /* search56_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace56_0 -> 65 in the cache */
   /* replace56_1 -> 148 in the cache */
   /* replace56_2 -> 147 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 65, 148, 147 },
      -1,
   } },

   /* ('b2f32', ('inot', 'a@64')) => ('bcsel_pan', ('u2u32', 'a'), 0.0, 1.0) */
   /* search57_0_0 -> 39 in the cache */
   /* search57_0 -> 140 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace57_0_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u32,
      -1, 0,
      { 39 },
      -1,
   } },
   /* replace57_1 -> 147 in the cache */
   /* replace57_2 -> 148 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 161, 147, 148 },
      -1,
   } },

   /* ('b2f32', 'a@64') => ('bcsel_pan', ('u2u32', 'a'), 1.0, 0.0) */
   /* search58_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2f32,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace58_0_0 -> 39 in the cache */
   /* replace58_0 -> 161 in the cache */
   /* replace58_1 -> 148 in the cache */
   /* replace58_2 -> 147 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 161, 148, 147 },
      -1,
   } },

   /* ('b2i8', ('inot', 'a@8')) => ('bcsel_pan', 'a', 0, 1) */
   /* search59_0_0 -> 21 in the cache */
   /* search59_0 -> 123 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace59_0 -> 21 in the cache */
   { .constant = {
      { nir_search_value_constant, 8 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 8 },
      nir_type_int, { 0x1ull /* 1 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 21, 166, 167 },
      -1,
   } },

   /* ('b2i8', 'a@8') => ('bcsel_pan', 'a', 1, 0) */
   /* search60_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace60_0 -> 21 in the cache */
   /* replace60_1 -> 167 in the cache */
   /* replace60_2 -> 166 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 21, 167, 166 },
      -1,
   } },

   /* ('b2i8', ('inot', 'a@16')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1) */
   /* search61_0_0 -> 47 in the cache */
   /* search61_0 -> 130 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace61_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 47 },
      -1,
   } },
   /* replace61_1 -> 166 in the cache */
   /* replace61_2 -> 167 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 172, 166, 167 },
      -1,
   } },

   /* ('b2i8', 'a@16') => ('bcsel_pan', ('u2u8', 'a'), 1, 0) */
   /* search62_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace62_0_0 -> 47 in the cache */
   /* replace62_0 -> 172 in the cache */
   /* replace62_1 -> 167 in the cache */
   /* replace62_2 -> 166 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 172, 167, 166 },
      -1,
   } },

   /* ('b2i8', ('inot', 'a@32')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1) */
   /* search63_0_0 -> 65 in the cache */
   /* search63_0 -> 135 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace63_0_0 -> 65 in the cache */
   /* replace63_0 -> 94 in the cache */
   /* replace63_1 -> 166 in the cache */
   /* replace63_2 -> 167 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 94, 166, 167 },
      -1,
   } },

   /* ('b2i8', 'a@32') => ('bcsel_pan', ('u2u8', 'a'), 1, 0) */
   /* search64_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace64_0_0 -> 65 in the cache */
   /* replace64_0 -> 94 in the cache */
   /* replace64_1 -> 167 in the cache */
   /* replace64_2 -> 166 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 94, 167, 166 },
      -1,
   } },

   /* ('b2i8', ('inot', 'a@64')) => ('bcsel_pan', ('u2u8', 'a'), 0, 1) */
   /* search65_0_0 -> 39 in the cache */
   /* search65_0 -> 140 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace65_0_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 39 },
      -1,
   } },
   /* replace65_1 -> 166 in the cache */
   /* replace65_2 -> 167 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 181, 166, 167 },
      -1,
   } },

   /* ('b2i8', 'a@64') => ('bcsel_pan', ('u2u8', 'a'), 1, 0) */
   /* search66_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i8,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace66_0_0 -> 39 in the cache */
   /* replace66_0 -> 181 in the cache */
   /* replace66_1 -> 167 in the cache */
   /* replace66_2 -> 166 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 181, 167, 166 },
      -1,
   } },

   /* ('b2i16', ('inot', 'a@8')) => ('bcsel_pan', ('i2i16', 'a'), 0, 1) */
   /* search67_0_0 -> 21 in the cache */
   /* search67_0 -> 123 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace67_0_0 -> 21 in the cache */
   /* replace67_0 -> 103 in the cache */
   { .constant = {
      { nir_search_value_constant, 16 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 16 },
      nir_type_int, { 0x1ull /* 1 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 103, 186, 187 },
      -1,
   } },

   /* ('b2i16', 'a@8') => ('bcsel_pan', ('i2i16', 'a'), 1, 0) */
   /* search68_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace68_0_0 -> 21 in the cache */
   /* replace68_0 -> 103 in the cache */
   /* replace68_1 -> 187 in the cache */
   /* replace68_2 -> 186 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 103, 187, 186 },
      -1,
   } },

   /* ('b2i16', ('inot', 'a@16')) => ('bcsel_pan', 'a', 0, 1) */
   /* search69_0_0 -> 47 in the cache */
   /* search69_0 -> 130 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace69_0 -> 47 in the cache */
   /* replace69_1 -> 186 in the cache */
   /* replace69_2 -> 187 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 47, 186, 187 },
      -1,
   } },

   /* ('b2i16', 'a@16') => ('bcsel_pan', 'a', 1, 0) */
   /* search70_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace70_0 -> 47 in the cache */
   /* replace70_1 -> 187 in the cache */
   /* replace70_2 -> 186 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 47, 187, 186 },
      -1,
   } },

   /* ('b2i16', ('inot', 'a@32')) => ('bcsel_pan', ('u2u16', 'a'), 0, 1) */
   /* search71_0_0 -> 65 in the cache */
   /* search71_0 -> 135 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace71_0_0 -> 65 in the cache */
   /* replace71_0 -> 91 in the cache */
   /* replace71_1 -> 186 in the cache */
   /* replace71_2 -> 187 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 91, 186, 187 },
      -1,
   } },

   /* ('b2i16', 'a@32') => ('bcsel_pan', ('u2u16', 'a'), 1, 0) */
   /* search72_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace72_0_0 -> 65 in the cache */
   /* replace72_0 -> 91 in the cache */
   /* replace72_1 -> 187 in the cache */
   /* replace72_2 -> 186 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 91, 187, 186 },
      -1,
   } },

   /* ('b2i16', ('inot', 'a@64')) => ('bcsel_pan', ('u2u16', 'a'), 0, 1) */
   /* search73_0_0 -> 39 in the cache */
   /* search73_0 -> 140 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace73_0_0 -> 39 in the cache */
   /* replace73_0 -> 142 in the cache */
   /* replace73_1 -> 186 in the cache */
   /* replace73_2 -> 187 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 142, 186, 187 },
      -1,
   } },

   /* ('b2i16', 'a@64') => ('bcsel_pan', ('u2u16', 'a'), 1, 0) */
   /* search74_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i16,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace74_0_0 -> 39 in the cache */
   /* replace74_0 -> 142 in the cache */
   /* replace74_1 -> 187 in the cache */
   /* replace74_2 -> 186 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 142, 187, 186 },
      -1,
   } },

   /* ('b2i32', ('inot', 'a@8')) => ('bcsel_pan', ('i2i32', 'a'), 0, 1) */
   /* search75_0_0 -> 21 in the cache */
   /* search75_0 -> 123 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace75_0_0 -> 21 in the cache */
   /* replace75_0 -> 45 in the cache */
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   /* replace75_2 -> 16 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 45, 204, 16 },
      -1,
   } },

   /* ('b2i32', 'a@8') => ('bcsel_pan', ('i2i32', 'a'), 1, 0) */
   /* search76_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace76_0_0 -> 21 in the cache */
   /* replace76_0 -> 45 in the cache */
   /* replace76_1 -> 16 in the cache */
   /* replace76_2 -> 204 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 45, 16, 204 },
      -1,
   } },

   /* ('b2i32', ('inot', 'a@16')) => ('bcsel_pan', ('i2i32', 'a'), 0, 1) */
   /* search77_0_0 -> 47 in the cache */
   /* search77_0 -> 130 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace77_0_0 -> 47 in the cache */
   /* replace77_0 -> 49 in the cache */
   /* replace77_1 -> 204 in the cache */
   /* replace77_2 -> 16 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 49, 204, 16 },
      -1,
   } },

   /* ('b2i32', 'a@16') => ('bcsel_pan', ('i2i32', 'a'), 1, 0) */
   /* search78_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace78_0_0 -> 47 in the cache */
   /* replace78_0 -> 49 in the cache */
   /* replace78_1 -> 16 in the cache */
   /* replace78_2 -> 204 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 49, 16, 204 },
      -1,
   } },

   /* ('b2i32', ('inot', 'a@32')) => ('bcsel_pan', 'a', 0, 1) */
   /* search79_0_0 -> 65 in the cache */
   /* search79_0 -> 135 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace79_0 -> 65 in the cache */
   /* replace79_1 -> 204 in the cache */
   /* replace79_2 -> 16 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 65, 204, 16 },
      -1,
   } },

   /* ('b2i32', 'a@32') => ('bcsel_pan', 'a', 1, 0) */
   /* search80_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace80_0 -> 65 in the cache */
   /* replace80_1 -> 16 in the cache */
   /* replace80_2 -> 204 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 65, 16, 204 },
      -1,
   } },

   /* ('b2i32', ('inot', 'a@64')) => ('bcsel_pan', ('u2u32', 'a'), 0, 1) */
   /* search81_0_0 -> 39 in the cache */
   /* search81_0 -> 140 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace81_0_0 -> 39 in the cache */
   /* replace81_0 -> 161 in the cache */
   /* replace81_1 -> 204 in the cache */
   /* replace81_2 -> 16 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 161, 204, 16 },
      -1,
   } },

   /* ('b2i32', 'a@64') => ('bcsel_pan', ('u2u32', 'a'), 1, 0) */
   /* search82_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i32,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace82_0_0 -> 39 in the cache */
   /* replace82_0 -> 161 in the cache */
   /* replace82_1 -> 16 in the cache */
   /* replace82_2 -> 204 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 161, 16, 204 },
      -1,
   } },

   /* ('b2i64', ('inot', 'a@8')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1) */
   /* search83_0_0 -> 21 in the cache */
   /* search83_0 -> 123 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 123 },
      -1,
   } },

   /* replace83_0_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i64,
      -1, 0,
      { 21 },
      -1,
   } },
   { .constant = {
      { nir_search_value_constant, 64 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 64 },
      nir_type_int, { 0x1ull /* 1 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 221, 222, 223 },
      -1,
   } },

   /* ('b2i64', 'a@8') => ('bcsel_pan', ('i2i64', 'a'), 1, 0) */
   /* search84_0 -> 21 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 21 },
      -1,
   } },

   /* replace84_0_0 -> 21 in the cache */
   /* replace84_0 -> 221 in the cache */
   /* replace84_1 -> 223 in the cache */
   /* replace84_2 -> 222 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 221, 223, 222 },
      -1,
   } },

   /* ('b2i64', ('inot', 'a@16')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1) */
   /* search85_0_0 -> 47 in the cache */
   /* search85_0 -> 130 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 130 },
      -1,
   } },

   /* replace85_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i64,
      -1, 0,
      { 47 },
      -1,
   } },
   /* replace85_1 -> 222 in the cache */
   /* replace85_2 -> 223 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 228, 222, 223 },
      -1,
   } },

   /* ('b2i64', 'a@16') => ('bcsel_pan', ('i2i64', 'a'), 1, 0) */
   /* search86_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 47 },
      -1,
   } },

   /* replace86_0_0 -> 47 in the cache */
   /* replace86_0 -> 228 in the cache */
   /* replace86_1 -> 223 in the cache */
   /* replace86_2 -> 222 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 228, 223, 222 },
      -1,
   } },

   /* ('b2i64', ('inot', 'a@32')) => ('bcsel_pan', ('i2i64', 'a'), 0, 1) */
   /* search87_0_0 -> 65 in the cache */
   /* search87_0 -> 135 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 135 },
      -1,
   } },

   /* replace87_0_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i64,
      -1, 0,
      { 65 },
      -1,
   } },
   /* replace87_1 -> 222 in the cache */
   /* replace87_2 -> 223 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 233, 222, 223 },
      -1,
   } },

   /* ('b2i64', 'a@32') => ('bcsel_pan', ('i2i64', 'a'), 1, 0) */
   /* search88_0 -> 65 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 65 },
      -1,
   } },

   /* replace88_0_0 -> 65 in the cache */
   /* replace88_0 -> 233 in the cache */
   /* replace88_1 -> 223 in the cache */
   /* replace88_2 -> 222 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 233, 223, 222 },
      -1,
   } },

   /* ('b2i64', ('inot', 'a@64')) => ('bcsel_pan', 'a', 0, 1) */
   /* search89_0_0 -> 39 in the cache */
   /* search89_0 -> 140 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 140 },
      -1,
   } },

   /* replace89_0 -> 39 in the cache */
   /* replace89_1 -> 222 in the cache */
   /* replace89_2 -> 223 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 39, 222, 223 },
      -1,
   } },

   /* ('b2i64', 'a@64') => ('bcsel_pan', 'a', 1, 0) */
   /* search90_0 -> 39 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_b2i64,
      -1, 0,
      { 39 },
      -1,
   } },

   /* replace90_0 -> 39 in the cache */
   /* replace90_1 -> 223 in the cache */
   /* replace90_2 -> 222 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel_pan,
      -1, 0,
      { 39, 223, 222 },
      -1,
   } },

   /* ('iand', ('ishl(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('lshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ishl', 'b', 'c'), 'd')) */
   { .variable = {
      { nir_search_value_variable, -4 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, -4 },
      1, /* b */
      true,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      1, 1,
      { 241, 242 },
      -1,
   } },
   { .variable = {
      { nir_search_value_variable, 32 },
      2, /* c */
      true,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 243, 244 },
      0,
   } },
   { .variable = {
      { nir_search_value_variable, -4 },
      3, /* d */
      true,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 2,
      { 245, 246 },
      -1,
   } },

   /* replace91_0 -> 241 in the cache */
   { .variable = {
      { nir_search_value_variable, 32 },
      2, /* c */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 248 },
      -1,
   } },
   { .variable = {
      { nir_search_value_variable, -4 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   /* replace91_2_0_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 0,
      { 250, 248 },
      -1,
   } },
   { .variable = {
      { nir_search_value_variable, -4 },
      3, /* d */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 251, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_and_pan,
      -1, 1,
      { 241, 249, 253 },
      -1,
   } },

   /* ('iand', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_and_pan', 'a', ('u2u8', 'b'), 'c') */
   { .variable = {
      { nir_search_value_variable, -3 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   /* search92_0_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 0,
      { 255, 77 },
      0,
   } },
   { .variable = {
      { nir_search_value_variable, -3 },
      2, /* c */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 256, 257 },
      -1,
   } },

   /* replace92_0 -> 255 in the cache */
   /* replace92_1_0 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 0,
      { 77 },
      -1,
   } },
   /* replace92_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_and_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishl', ('iand', 'a', '#b'), '#c') => ('lshift_and_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c')) */
   { .variable = {
      { nir_search_value_variable, -2 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, -2 },
      1, /* b */
      true,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 261, 262 },
      -1,
   } },
   /* search93_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 263, 244 },
      -1,
   } },

   /* replace93_0 -> 261 in the cache */
   /* replace93_1_0 -> 248 in the cache */
   /* replace93_1 -> 249 in the cache */
   { .variable = {
      { nir_search_value_variable, -2 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   /* replace93_2_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 0,
      { 265, 248 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_and_pan,
      -1, 0,
      { 261, 249, 266 },
      -1,
   } },

   /* ('ior', ('ishl(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('lshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ishl', 'b', 'c'), 'd')) */
   /* search94_0_0_0 -> 241 in the cache */
   /* search94_0_0_1 -> 242 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      1, 1,
      { 241, 242 },
      -1,
   } },
   /* search94_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 268, 244 },
      0,
   } },
   /* search94_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 2,
      { 269, 246 },
      -1,
   } },

   /* replace94_0 -> 241 in the cache */
   /* replace94_1_0 -> 248 in the cache */
   /* replace94_1 -> 249 in the cache */
   /* replace94_2_0_0 -> 250 in the cache */
   /* replace94_2_0_1 -> 248 in the cache */
   /* replace94_2_0 -> 251 in the cache */
   /* replace94_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 251, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_or_pan,
      -1, 1,
      { 241, 249, 271 },
      -1,
   } },

   /* ('ior', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_or_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search95_0_0 -> 255 in the cache */
   /* search95_0_1 -> 77 in the cache */
   /* search95_0 -> 256 in the cache */
   /* search95_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 256, 257 },
      -1,
   } },

   /* replace95_0 -> 255 in the cache */
   /* replace95_1_0 -> 77 in the cache */
   /* replace95_1 -> 259 in the cache */
   /* replace95_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_or_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishl', ('ior', 'a', '#b'), '#c') => ('lshift_or_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c')) */
   /* search96_0_0 -> 261 in the cache */
   /* search96_0_1 -> 262 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 261, 262 },
      -1,
   } },
   /* search96_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 275, 244 },
      -1,
   } },

   /* replace96_0 -> 261 in the cache */
   /* replace96_1_0 -> 248 in the cache */
   /* replace96_1 -> 249 in the cache */
   /* replace96_2_0 -> 265 in the cache */
   /* replace96_2_1 -> 248 in the cache */
   /* replace96_2 -> 266 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_or_pan,
      -1, 0,
      { 261, 249, 266 },
      -1,
   } },

   /* ('ixor', ('ishl(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('lshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ishl', 'b', 'c'), 'd')) */
   /* search97_0_0_0 -> 241 in the cache */
   /* search97_0_0_1 -> 242 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      1, 1,
      { 241, 242 },
      -1,
   } },
   /* search97_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 278, 244 },
      0,
   } },
   /* search97_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 2,
      { 279, 246 },
      -1,
   } },

   /* replace97_0 -> 241 in the cache */
   /* replace97_1_0 -> 248 in the cache */
   /* replace97_1 -> 249 in the cache */
   /* replace97_2_0_0 -> 250 in the cache */
   /* replace97_2_0_1 -> 248 in the cache */
   /* replace97_2_0 -> 251 in the cache */
   /* replace97_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 251, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_xor_pan,
      -1, 1,
      { 241, 249, 281 },
      -1,
   } },

   /* ('ixor', ('ishl(is_used_once)', 'a', 'b'), 'c') => ('lshift_xor_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search98_0_0 -> 255 in the cache */
   /* search98_0_1 -> 77 in the cache */
   /* search98_0 -> 256 in the cache */
   /* search98_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 256, 257 },
      -1,
   } },

   /* replace98_0 -> 255 in the cache */
   /* replace98_1_0 -> 77 in the cache */
   /* replace98_1 -> 259 in the cache */
   /* replace98_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_xor_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishl', ('ixor', 'a', '#b'), '#c') => ('lshift_xor_pan', 'a', ('u2u8', 'c'), ('ishl', 'b', 'c')) */
   /* search99_0_0 -> 261 in the cache */
   /* search99_0_1 -> 262 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 261, 262 },
      -1,
   } },
   /* search99_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 1,
      { 285, 244 },
      -1,
   } },

   /* replace99_0 -> 261 in the cache */
   /* replace99_1_0 -> 248 in the cache */
   /* replace99_1 -> 249 in the cache */
   /* replace99_2_0 -> 265 in the cache */
   /* replace99_2_1 -> 248 in the cache */
   /* replace99_2 -> 266 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_xor_pan,
      -1, 0,
      { 261, 249, 266 },
      -1,
   } },

   /* ('iand', ('ushr(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('rshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ushr', 'b', 'c'), 'd')) */
   /* search100_0_0_0 -> 241 in the cache */
   /* search100_0_0_1 -> 242 in the cache */
   /* search100_0_0 -> 243 in the cache */
   /* search100_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 243, 244 },
      0,
   } },
   /* search100_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 2,
      { 288, 246 },
      -1,
   } },

   /* replace100_0 -> 241 in the cache */
   /* replace100_1_0 -> 248 in the cache */
   /* replace100_1 -> 249 in the cache */
   /* replace100_2_0_0 -> 250 in the cache */
   /* replace100_2_0_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 0,
      { 250, 248 },
      -1,
   } },
   /* replace100_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 290, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_and_pan,
      -1, 1,
      { 241, 249, 291 },
      -1,
   } },

   /* ('iand', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_and_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search101_0_0 -> 255 in the cache */
   /* search101_0_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 0,
      { 255, 77 },
      0,
   } },
   /* search101_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 293, 257 },
      -1,
   } },

   /* replace101_0 -> 255 in the cache */
   /* replace101_1_0 -> 77 in the cache */
   /* replace101_1 -> 259 in the cache */
   /* replace101_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_and_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ushr', ('iand', 'a', '#b'), '#c') => ('rshift_and_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c')) */
   /* search102_0_0 -> 261 in the cache */
   /* search102_0_1 -> 262 in the cache */
   /* search102_0 -> 263 in the cache */
   /* search102_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 263, 244 },
      -1,
   } },

   /* replace102_0 -> 261 in the cache */
   /* replace102_1_0 -> 248 in the cache */
   /* replace102_1 -> 249 in the cache */
   /* replace102_2_0 -> 265 in the cache */
   /* replace102_2_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 0,
      { 265, 248 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_and_pan,
      -1, 0,
      { 261, 249, 297 },
      -1,
   } },

   /* ('ior', ('ushr(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('rshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ushr', 'b', 'c'), 'd')) */
   /* search103_0_0_0 -> 241 in the cache */
   /* search103_0_0_1 -> 242 in the cache */
   /* search103_0_0 -> 268 in the cache */
   /* search103_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 268, 244 },
      0,
   } },
   /* search103_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 2,
      { 299, 246 },
      -1,
   } },

   /* replace103_0 -> 241 in the cache */
   /* replace103_1_0 -> 248 in the cache */
   /* replace103_1 -> 249 in the cache */
   /* replace103_2_0_0 -> 250 in the cache */
   /* replace103_2_0_1 -> 248 in the cache */
   /* replace103_2_0 -> 290 in the cache */
   /* replace103_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 290, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_or_pan,
      -1, 1,
      { 241, 249, 301 },
      -1,
   } },

   /* ('ior', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_or_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search104_0_0 -> 255 in the cache */
   /* search104_0_1 -> 77 in the cache */
   /* search104_0 -> 293 in the cache */
   /* search104_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 293, 257 },
      -1,
   } },

   /* replace104_0 -> 255 in the cache */
   /* replace104_1_0 -> 77 in the cache */
   /* replace104_1 -> 259 in the cache */
   /* replace104_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_or_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ushr', ('ior', 'a', '#b'), '#c') => ('rshift_or_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c')) */
   /* search105_0_0 -> 261 in the cache */
   /* search105_0_1 -> 262 in the cache */
   /* search105_0 -> 275 in the cache */
   /* search105_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 275, 244 },
      -1,
   } },

   /* replace105_0 -> 261 in the cache */
   /* replace105_1_0 -> 248 in the cache */
   /* replace105_1 -> 249 in the cache */
   /* replace105_2_0 -> 265 in the cache */
   /* replace105_2_1 -> 248 in the cache */
   /* replace105_2 -> 297 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_or_pan,
      -1, 0,
      { 261, 249, 297 },
      -1,
   } },

   /* ('ixor', ('ushr(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('rshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ushr', 'b', 'c'), 'd')) */
   /* search106_0_0_0 -> 241 in the cache */
   /* search106_0_0_1 -> 242 in the cache */
   /* search106_0_0 -> 278 in the cache */
   /* search106_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 278, 244 },
      0,
   } },
   /* search106_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 2,
      { 307, 246 },
      -1,
   } },

   /* replace106_0 -> 241 in the cache */
   /* replace106_1_0 -> 248 in the cache */
   /* replace106_1 -> 249 in the cache */
   /* replace106_2_0_0 -> 250 in the cache */
   /* replace106_2_0_1 -> 248 in the cache */
   /* replace106_2_0 -> 290 in the cache */
   /* replace106_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 290, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_xor_pan,
      -1, 1,
      { 241, 249, 309 },
      -1,
   } },

   /* ('ixor', ('ushr(is_used_once)', 'a', 'b'), 'c') => ('rshift_xor_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search107_0_0 -> 255 in the cache */
   /* search107_0_1 -> 77 in the cache */
   /* search107_0 -> 293 in the cache */
   /* search107_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 293, 257 },
      -1,
   } },

   /* replace107_0 -> 255 in the cache */
   /* replace107_1_0 -> 77 in the cache */
   /* replace107_1 -> 259 in the cache */
   /* replace107_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_xor_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ushr', ('ixor', 'a', '#b'), '#c') => ('rshift_xor_pan', 'a', ('u2u8', 'c'), ('ushr', 'b', 'c')) */
   /* search108_0_0 -> 261 in the cache */
   /* search108_0_1 -> 262 in the cache */
   /* search108_0 -> 285 in the cache */
   /* search108_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 1,
      { 285, 244 },
      -1,
   } },

   /* replace108_0 -> 261 in the cache */
   /* replace108_1_0 -> 248 in the cache */
   /* replace108_1 -> 249 in the cache */
   /* replace108_2_0 -> 265 in the cache */
   /* replace108_2_1 -> 248 in the cache */
   /* replace108_2 -> 297 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_xor_pan,
      -1, 0,
      { 261, 249, 297 },
      -1,
   } },

   /* ('iand', ('ishr(is_used_once)', ('iand', 'a', '#b'), '#c'), '#d') => ('arshift_and_pan', 'a', ('u2u8', 'c'), ('iand', ('ishr', 'b', 'c'), 'd')) */
   /* search109_0_0_0 -> 241 in the cache */
   /* search109_0_0_1 -> 242 in the cache */
   /* search109_0_0 -> 243 in the cache */
   /* search109_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 243, 244 },
      0,
   } },
   /* search109_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 2,
      { 315, 246 },
      -1,
   } },

   /* replace109_0 -> 241 in the cache */
   /* replace109_1_0 -> 248 in the cache */
   /* replace109_1 -> 249 in the cache */
   /* replace109_2_0_0 -> 250 in the cache */
   /* replace109_2_0_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 0,
      { 250, 248 },
      -1,
   } },
   /* replace109_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 317, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_and_pan,
      -1, 1,
      { 241, 249, 318 },
      -1,
   } },

   /* ('iand', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_and_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search110_0_0 -> 255 in the cache */
   /* search110_0_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 0,
      { 255, 77 },
      0,
   } },
   /* search110_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 320, 257 },
      -1,
   } },

   /* replace110_0 -> 255 in the cache */
   /* replace110_1_0 -> 77 in the cache */
   /* replace110_1 -> 259 in the cache */
   /* replace110_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_and_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishr', ('iand', 'a', '#b'), '#c') => ('arshift_and_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c')) */
   /* search111_0_0 -> 261 in the cache */
   /* search111_0_1 -> 262 in the cache */
   /* search111_0 -> 263 in the cache */
   /* search111_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 263, 244 },
      -1,
   } },

   /* replace111_0 -> 261 in the cache */
   /* replace111_1_0 -> 248 in the cache */
   /* replace111_1 -> 249 in the cache */
   /* replace111_2_0 -> 265 in the cache */
   /* replace111_2_1 -> 248 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 0,
      { 265, 248 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_and_pan,
      -1, 0,
      { 261, 249, 324 },
      -1,
   } },

   /* ('ior', ('ishr(is_used_once)', ('ior', 'a', '#b'), '#c'), '#d') => ('arshift_or_pan', 'a', ('u2u8', 'c'), ('ior', ('ishr', 'b', 'c'), 'd')) */
   /* search112_0_0_0 -> 241 in the cache */
   /* search112_0_0_1 -> 242 in the cache */
   /* search112_0_0 -> 268 in the cache */
   /* search112_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 268, 244 },
      0,
   } },
   /* search112_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 2,
      { 326, 246 },
      -1,
   } },

   /* replace112_0 -> 241 in the cache */
   /* replace112_1_0 -> 248 in the cache */
   /* replace112_1 -> 249 in the cache */
   /* replace112_2_0_0 -> 250 in the cache */
   /* replace112_2_0_1 -> 248 in the cache */
   /* replace112_2_0 -> 317 in the cache */
   /* replace112_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 317, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_or_pan,
      -1, 1,
      { 241, 249, 328 },
      -1,
   } },

   /* ('ior', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_or_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search113_0_0 -> 255 in the cache */
   /* search113_0_1 -> 77 in the cache */
   /* search113_0 -> 320 in the cache */
   /* search113_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 320, 257 },
      -1,
   } },

   /* replace113_0 -> 255 in the cache */
   /* replace113_1_0 -> 77 in the cache */
   /* replace113_1 -> 259 in the cache */
   /* replace113_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_or_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishr', ('ior', 'a', '#b'), '#c') => ('arshift_or_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c')) */
   /* search114_0_0 -> 261 in the cache */
   /* search114_0_1 -> 262 in the cache */
   /* search114_0 -> 275 in the cache */
   /* search114_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 275, 244 },
      -1,
   } },

   /* replace114_0 -> 261 in the cache */
   /* replace114_1_0 -> 248 in the cache */
   /* replace114_1 -> 249 in the cache */
   /* replace114_2_0 -> 265 in the cache */
   /* replace114_2_1 -> 248 in the cache */
   /* replace114_2 -> 324 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_or_pan,
      -1, 0,
      { 261, 249, 324 },
      -1,
   } },

   /* ('ixor', ('ishr(is_used_once)', ('ixor', 'a', '#b'), '#c'), '#d') => ('arshift_xor_pan', 'a', ('u2u8', 'c'), ('ixor', ('ishr', 'b', 'c'), 'd')) */
   /* search115_0_0_0 -> 241 in the cache */
   /* search115_0_0_1 -> 242 in the cache */
   /* search115_0_0 -> 278 in the cache */
   /* search115_0_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 278, 244 },
      0,
   } },
   /* search115_1 -> 246 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 2,
      { 334, 246 },
      -1,
   } },

   /* replace115_0 -> 241 in the cache */
   /* replace115_1_0 -> 248 in the cache */
   /* replace115_1 -> 249 in the cache */
   /* replace115_2_0_0 -> 250 in the cache */
   /* replace115_2_0_1 -> 248 in the cache */
   /* replace115_2_0 -> 317 in the cache */
   /* replace115_2_1 -> 252 in the cache */
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 317, 252 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, -4 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_xor_pan,
      -1, 1,
      { 241, 249, 336 },
      -1,
   } },

   /* ('ixor', ('ishr(is_used_once)', 'a', 'b'), 'c') => ('arshift_xor_pan', 'a', ('u2u8', 'b'), 'c') */
   /* search116_0_0 -> 255 in the cache */
   /* search116_0_1 -> 77 in the cache */
   /* search116_0 -> 320 in the cache */
   /* search116_1 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 320, 257 },
      -1,
   } },

   /* replace116_0 -> 255 in the cache */
   /* replace116_1_0 -> 77 in the cache */
   /* replace116_1 -> 259 in the cache */
   /* replace116_2 -> 257 in the cache */
   { .expression = {
      { nir_search_value_expression, -3 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_xor_pan,
      -1, 0,
      { 255, 259, 257 },
      -1,
   } },

   /* ('ishr', ('ixor', 'a', '#b'), '#c') => ('arshift_xor_pan', 'a', ('u2u8', 'c'), ('ishr', 'b', 'c')) */
   /* search117_0_0 -> 261 in the cache */
   /* search117_0_1 -> 262 in the cache */
   /* search117_0 -> 285 in the cache */
   /* search117_1 -> 244 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 1,
      { 285, 244 },
      -1,
   } },

   /* replace117_0 -> 261 in the cache */
   /* replace117_1_0 -> 248 in the cache */
   /* replace117_1 -> 249 in the cache */
   /* replace117_2_0 -> 265 in the cache */
   /* replace117_2_1 -> 248 in the cache */
   /* replace117_2 -> 324 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_xor_pan,
      -1, 0,
      { 261, 249, 324 },
      -1,
   } },

   /* ('iand', 'a', 'b') => ('lshift_and_pan', 'a', 0, 'b') */
   /* search118_0 -> 261 in the cache */
   /* search118_1 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_iand,
      0, 1,
      { 261, 265 },
      -1,
   } },

   /* replace118_0 -> 261 in the cache */
   /* replace118_1 -> 166 in the cache */
   /* replace118_2 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_lshift_and_pan,
      -1, 0,
      { 261, 166, 265 },
      -1,
   } },

   /* ('ior', 'a', 'b') => ('lshift_or_pan', 'a', 0, 'b') */
   /* search119_0 -> 261 in the cache */
   /* search119_1 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ior,
      0, 1,
      { 261, 265 },
      -1,
   } },

   /* replace119_0 -> 261 in the cache */
   /* replace119_1 -> 166 in the cache */
   /* replace119_2 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_lshift_or_pan,
      -1, 0,
      { 261, 166, 265 },
      -1,
   } },

   /* ('ixor', 'a', 'b') => ('lshift_xor_pan', 'a', 0, 'b') */
   /* search120_0 -> 261 in the cache */
   /* search120_1 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ixor,
      0, 1,
      { 261, 265 },
      -1,
   } },

   /* replace120_0 -> 261 in the cache */
   /* replace120_1 -> 166 in the cache */
   /* replace120_2 -> 265 in the cache */
   { .expression = {
      { nir_search_value_expression, -2 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_lshift_xor_pan,
      -1, 0,
      { 261, 166, 265 },
      -1,
   } },

   /* ('ishl', 'a', 'b') => ('lshift_or_pan', 'a', ('u2u8', 'b'), 0) */
   /* search121_0 -> 0 in the cache */
   /* search121_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishl,
      -1, 0,
      { 0, 77 },
      -1,
   } },

   /* replace121_0 -> 0 in the cache */
   /* replace121_1_0 -> 77 in the cache */
   /* replace121_1 -> 259 in the cache */
   { .constant = {
      { nir_search_value_constant, -1 },
      nir_type_int, { 0x0ull /* 0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lshift_or_pan,
      -1, 0,
      { 0, 259, 349 },
      -1,
   } },

   /* ('ushr', 'a', 'b') => ('rshift_or_pan', 'a', ('u2u8', 'b'), 0) */
   /* search122_0 -> 0 in the cache */
   /* search122_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ushr,
      -1, 0,
      { 0, 77 },
      -1,
   } },

   /* replace122_0 -> 0 in the cache */
   /* replace122_1_0 -> 77 in the cache */
   /* replace122_1 -> 259 in the cache */
   /* replace122_2 -> 349 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rshift_or_pan,
      -1, 0,
      { 0, 259, 349 },
      -1,
   } },

   /* ('ishr', 'a', 'b') => ('arshift_or_pan', 'a', ('u2u8', 'b'), 0) */
   /* search123_0 -> 0 in the cache */
   /* search123_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ishr,
      -1, 0,
      { 0, 77 },
      -1,
   } },

   /* replace123_0 -> 0 in the cache */
   /* replace123_1_0 -> 77 in the cache */
   /* replace123_1 -> 259 in the cache */
   /* replace123_2 -> 349 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_arshift_or_pan,
      -1, 0,
      { 0, 259, 349 },
      -1,
   } },

   /* ('urol', 'a', 'b') => ('lrot_or_pan', 'a', ('u2u8', 'b'), 0) */
   /* search124_0 -> 0 in the cache */
   /* search124_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_urol,
      -1, 0,
      { 0, 77 },
      -1,
   } },

   /* replace124_0 -> 0 in the cache */
   /* replace124_1_0 -> 77 in the cache */
   /* replace124_1 -> 259 in the cache */
   /* replace124_2 -> 349 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_lrot_or_pan,
      -1, 0,
      { 0, 259, 349 },
      -1,
   } },

   /* ('uror', 'a', 'b') => ('rrot_or_pan', 'a', ('u2u8', 'b'), 0) */
   /* search125_0 -> 0 in the cache */
   /* search125_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_uror,
      -1, 0,
      { 0, 77 },
      -1,
   } },

   /* replace125_0 -> 0 in the cache */
   /* replace125_1_0 -> 77 in the cache */
   /* replace125_1 -> 259 in the cache */
   /* replace125_2 -> 349 in the cache */
   { .expression = {
      { nir_search_value_expression, -1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_rrot_or_pan,
      -1, 0,
      { 0, 259, 349 },
      -1,
   } },

   /* ('imul_high', 'a@8', 'b@8') => ('u2u8', ('extract_u8', ('imul', ('i2i16', 'a'), ('i2i16', 'b')), 1)) */
   /* search126_0 -> 21 in the cache */
   /* search126_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul_high,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace126_0_0_0_0 -> 21 in the cache */
   /* replace126_0_0_0 -> 103 in the cache */
   /* replace126_0_0_1_0 -> 22 in the cache */
   /* replace126_0_0_1 -> 104 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul,
      0, 1,
      { 103, 104 },
      -1,
   } },
   /* replace126_0_1 -> 187 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_extract_u8,
      -1, 1,
      { 360, 187 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 1,
      { 361 },
      -1,
   } },

   /* ('umul_high', 'a@8', 'b@8') => ('u2u8', ('extract_u8', ('imul', ('u2u16', 'a'), ('u2u16', 'b')), 1)) */
   /* search127_0 -> 21 in the cache */
   /* search127_1 -> 22 in the cache */
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umul_high,
      0, 1,
      { 21, 22 },
      -1,
   } },

   /* replace127_0_0_0_0 -> 21 in the cache */
   /* replace127_0_0_0 -> 116 in the cache */
   /* replace127_0_0_1_0 -> 22 in the cache */
   /* replace127_0_0_1 -> 117 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul,
      0, 1,
      { 116, 117 },
      -1,
   } },
   /* replace127_0_1 -> 187 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_extract_u8,
      -1, 1,
      { 364, 187 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 8 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u8,
      -1, 1,
      { 365 },
      -1,
   } },

   /* ('imul_high', 'a@16', 'b@16') => ('unpack_32_2x16_split_y', ('imul', ('i2i32', 'a'), ('i2i32', 'b'))) */
   /* search128_0 -> 47 in the cache */
   { .variable = {
      { nir_search_value_variable, 16 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul_high,
      0, 1,
      { 47, 367 },
      -1,
   } },

   /* replace128_0_0_0 -> 47 in the cache */
   /* replace128_0_0 -> 49 in the cache */
   /* replace128_0_1_0 -> 367 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_i2i32,
      -1, 0,
      { 367 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul,
      0, 1,
      { 49, 369 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_32_2x16_split_y,
      -1, 1,
      { 370 },
      -1,
   } },

   /* ('umul_high', 'a@16', 'b@16') => ('unpack_32_2x16_split_y', ('imul', ('u2u32', 'a'), ('u2u32', 'b'))) */
   /* search129_0 -> 47 in the cache */
   /* search129_1 -> 367 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umul_high,
      0, 1,
      { 47, 367 },
      -1,
   } },

   /* replace129_0_0_0 -> 47 in the cache */
   /* replace129_0_0 -> 55 in the cache */
   /* replace129_0_1_0 -> 367 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u32,
      -1, 0,
      { 367 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul,
      0, 1,
      { 55, 373 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_32_2x16_split_y,
      -1, 1,
      { 374 },
      -1,
   } },

   /* ('imul_high', 'a@32', 'b@32') => ('unpack_64_2x32_split_y', ('imul_2x32_64', 'a', 'b')) */
   /* search130_0 -> 65 in the cache */
   /* search130_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul_high,
      0, 1,
      { 65, 77 },
      -1,
   } },

   /* replace130_0_0 -> 65 in the cache */
   /* replace130_0_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_imul_2x32_64,
      0, 1,
      { 65, 77 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_64_2x32_split_y,
      -1, 1,
      { 377 },
      -1,
   } },

   /* ('umul_high', 'a@32', 'b@32') => ('unpack_64_2x32_split_y', ('umul_2x32_64', 'a', 'b')) */
   /* search131_0 -> 65 in the cache */
   /* search131_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umul_high,
      0, 1,
      { 65, 77 },
      -1,
   } },

   /* replace131_0_0 -> 65 in the cache */
   /* replace131_0_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 64 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_umul_2x32_64,
      0, 1,
      { 65, 77 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_unpack_64_2x32_split_y,
      -1, 1,
      { 380 },
      -1,
   } },

   /* ('fpow', 'a@16', 'b@16') => ('fexp2', ('fmul', ('flog2', 'a'), 'b')) */
   /* search132_0 -> 47 in the cache */
   /* search132_1 -> 367 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fpow,
      -1, 0,
      { 47, 367 },
      -1,
   } },

   /* replace132_0_0_0 -> 47 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_flog2,
      -1, 0,
      { 47 },
      -1,
   } },
   /* replace132_0_1 -> 367 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fmul,
      0, 1,
      { 383, 367 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fexp2,
      -1, 1,
      { 384 },
      -1,
   } },

   /* ('ldexp', 'a@16', 'b') => ('ldexp16_pan', 'a', ('u2u16', ('imin', ('imax', 'b', -127), 127))) */
   /* search133_0 -> 47 in the cache */
   /* search133_1 -> 77 in the cache */
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ldexp,
      -1, 0,
      { 47, 77 },
      -1,
   } },

   /* replace133_0 -> 47 in the cache */
   /* replace133_1_0_0_0 -> 77 in the cache */
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_int, { 0xffffffffffffff81ull /* -127 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_imax,
      1, 1,
      { 77, 387 },
      -1,
   } },
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_int, { 0x7full /* 127 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_imin,
      0, 2,
      { 388, 389 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_u2u16,
      -1, 2,
      { 390 },
      -1,
   } },
   { .expression = {
      { nir_search_value_expression, 16 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_ldexp16_pan,
      -1, 2,
      { 47, 391 },
      -1,
   } },

};

UNUSED static const nir_search_expression_cond bifrost_nir_lower_algebraic_late_expression_cond[] = {
   is_used_once,
};


static const struct transform bifrost_nir_lower_algebraic_late_transforms[] = {
   { ~0, ~0, ~0 }, /* Sentinel */

   { 2, 3, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 12, 13, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 23, 25, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 26, 27, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 28, 30, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 31, 32, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 33, 35, 0 },
   { 72, 74, 1 },
   { 82, 83, 1 },
   { 34, 89, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 36, 38, 0 },
   { 75, 76, 1 },
   { 84, 85, 1 },
   { 37, 87, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 40, 43, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 44, 46, 1 },
   { 48, 50, 1 },
   { 57, 60, 1 },
   { 66, 68, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 51, 53, 1 },
   { 54, 56, 1 },
   { 61, 64, 1 },
   { 69, 71, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 78, 81, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 90, 92, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 93, 95, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 96, 99, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 100, 21, 0 },
   { 101, 47, 0 },
   { 102, 65, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 24, 106, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 107, 109, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 110, 112, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 113, 115, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 29, 119, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 120, 122, 1 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 128, 129, 0 },
   { 133, 134, 0 },
   { 138, 139, 0 },
   { 144, 145, 0 },
   { 150, 151, 0 },
   { 154, 155, 0 },
   { 158, 159, 0 },
   { 163, 164, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 169, 170, 2 },
   { 174, 175, 2 },
   { 178, 179, 2 },
   { 183, 184, 2 },
   { 189, 190, 2 },
   { 193, 194, 2 },
   { 197, 198, 2 },
   { 201, 202, 2 },
   { 206, 207, 2 },
   { 210, 211, 2 },
   { 214, 215, 2 },
   { 218, 219, 2 },
   { 225, 226, 2 },
   { 230, 231, 2 },
   { 235, 236, 2 },
   { 239, 240, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 348, 350, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 351, 352, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 353, 354, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 355, 356, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 357, 358, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 359, 362, 2 },
   { 368, 371, 2 },
   { 376, 378, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 363, 366, 2 },
   { 372, 375, 2 },
   { 379, 381, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 382, 385, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 386, 392, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 10, 8, 0 },
   { 12, 13, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 7, 8, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 18, 20, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 124, 127, 0 },
   { 128, 129, 0 },
   { 131, 132, 0 },
   { 133, 134, 0 },
   { 136, 137, 0 },
   { 138, 139, 0 },
   { 141, 143, 0 },
   { 144, 145, 0 },
   { 146, 149, 0 },
   { 150, 151, 0 },
   { 152, 153, 0 },
   { 154, 155, 0 },
   { 156, 157, 0 },
   { 158, 159, 0 },
   { 160, 162, 0 },
   { 163, 164, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 165, 168, 2 },
   { 169, 170, 2 },
   { 171, 173, 2 },
   { 174, 175, 2 },
   { 176, 177, 2 },
   { 178, 179, 2 },
   { 180, 182, 2 },
   { 183, 184, 2 },
   { 185, 188, 2 },
   { 189, 190, 2 },
   { 191, 192, 2 },
   { 193, 194, 2 },
   { 195, 196, 2 },
   { 197, 198, 2 },
   { 199, 200, 2 },
   { 201, 202, 2 },
   { 203, 205, 2 },
   { 206, 207, 2 },
   { 208, 209, 2 },
   { 210, 211, 2 },
   { 212, 213, 2 },
   { 214, 215, 2 },
   { 216, 217, 2 },
   { 218, 219, 2 },
   { 220, 224, 2 },
   { 225, 226, 2 },
   { 227, 229, 2 },
   { 230, 231, 2 },
   { 232, 234, 2 },
   { 235, 236, 2 },
   { 237, 238, 2 },
   { 239, 240, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 264, 267, 2 },
   { 348, 350, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 276, 277, 2 },
   { 348, 350, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 286, 287, 2 },
   { 348, 350, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 296, 298, 2 },
   { 351, 352, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 305, 306, 2 },
   { 351, 352, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 313, 314, 2 },
   { 351, 352, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 323, 325, 2 },
   { 353, 354, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 332, 333, 2 },
   { 353, 354, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 340, 341, 2 },
   { 353, 354, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 258, 260, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 294, 295, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 321, 322, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 258, 260, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 294, 295, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 321, 322, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 258, 260, 2 },
   { 294, 295, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 258, 260, 2 },
   { 321, 322, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 294, 295, 2 },
   { 321, 322, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 273, 274, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 303, 304, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 330, 331, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 273, 274, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 303, 304, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 330, 331, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 273, 274, 2 },
   { 303, 304, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 273, 274, 2 },
   { 330, 331, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 303, 304, 2 },
   { 330, 331, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 283, 284, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 311, 312, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 338, 339, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 283, 284, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 311, 312, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 338, 339, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 283, 284, 2 },
   { 311, 312, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 283, 284, 2 },
   { 338, 339, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 311, 312, 2 },
   { 338, 339, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 247, 254, 2 },
   { 258, 260, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 289, 292, 2 },
   { 294, 295, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 316, 319, 2 },
   { 321, 322, 2 },
   { 342, 343, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 270, 272, 2 },
   { 273, 274, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 300, 302, 2 },
   { 303, 304, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 327, 329, 2 },
   { 330, 331, 2 },
   { 344, 345, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 280, 282, 2 },
   { 283, 284, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 308, 310, 2 },
   { 311, 312, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 335, 337, 2 },
   { 338, 339, 2 },
   { 346, 347, 2 },
   { ~0, ~0, ~0 }, /* Sentinel */

};

static const struct per_op_table bifrost_nir_lower_algebraic_late_pass_op_table[nir_num_search_ops] = {
   [nir_op_fmul] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         0,
         2,
         2,
         2,
      },
   },
   [nir_op_fmin] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 3,
      .table = (const uint16_t []) {
      
         0,
         3,
         0,
         3,
         3,
         45,
         0,
         45,
         0,
      },
   },
   [nir_op_fmax] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 3,
      .table = (const uint16_t []) {
      
         0,
         4,
         0,
         4,
         4,
         44,
         0,
         44,
         0,
      },
   },
   [nir_op_bcsel_pan] = {
      .filter = (const uint16_t []) {
         0,
         0,
         0,
         0,
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         0,
         0,
         46,
         46,
         0,
         0,
         46,
         46,
      },
   },
   [nir_op_iadd] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         0,
         5,
         5,
         5,
      },
   },
   [nir_op_imin] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         6,
      },
   },
   [nir_op_imax] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         7,
      },
   },
   [nir_op_umin] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         8,
      },
   },
   [nir_op_umax] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         9,
      },
   },
   [nir_search_op_f2i] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         10,
      },
   },
   [nir_search_op_f2u] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         11,
      },
   },
   [nir_op_unpack_64_2x32] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         12,
      },
   },
   [nir_search_op_i2f] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         13,
      },
   },
   [nir_search_op_u2f] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         14,
      },
   },
   [nir_op_pack_half_2x16_split] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         15,
      },
   },
   [nir_op_pack_uvec2_to_uint] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         16,
      },
   },
   [nir_op_pack_uvec4_to_uint] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         17,
      },
   },
   [nir_op_ffract] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         18,
      },
   },
   [nir_search_op_i2i] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         19,
      },
   },
   [nir_op_ilt_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         20,
      },
   },
   [nir_op_ige_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         21,
      },
   },
   [nir_op_ieq_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         22,
      },
   },
   [nir_op_ine_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         23,
      },
   },
   [nir_op_ult_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         24,
      },
   },
   [nir_op_uge_pan] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         25,
      },
   },
   [nir_search_op_b2f] = {
      .filter = (const uint16_t []) {
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         26,
         47,
      },
   },
   [nir_op_inot] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         27,
      },
   },
   [nir_search_op_b2i] = {
      .filter = (const uint16_t []) {
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         28,
         48,
      },
   },
   [nir_op_iand] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         3,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         5,
         2,
         2,
         6,
         3,
         3,
         7,
         4,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 8,
      .table = (const uint16_t []) {
      
         29,
         30,
         58,
         59,
         60,
         58,
         59,
         60,
         30,
         30,
         61,
         62,
         63,
         85,
         86,
         87,
         58,
         61,
         58,
         64,
         65,
         58,
         64,
         65,
         59,
         62,
         64,
         59,
         66,
         64,
         59,
         66,
         60,
         63,
         65,
         66,
         60,
         65,
         66,
         60,
         58,
         85,
         58,
         64,
         65,
         58,
         64,
         65,
         59,
         86,
         64,
         59,
         66,
         64,
         59,
         66,
         60,
         87,
         65,
         66,
         60,
         65,
         66,
         60,
      },
   },
   [nir_op_ishl] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         3,
         0,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         2,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         3,
         3,
         3,
         0,
         0,
         0,
         0,
         0,
         0,
         4,
         4,
         4,
         0,
         0,
         0,
         2,
         2,
         2,
         3,
         3,
         3,
         4,
         4,
         4,
      },
      
      .num_filtered_states = 5,
      .table = (const uint16_t []) {
      
         31,
         31,
         31,
         31,
         31,
         31,
         31,
         31,
         31,
         31,
         31,
         49,
         31,
         31,
         31,
         31,
         50,
         31,
         31,
         31,
         31,
         51,
         31,
         31,
         31,
      },
   },
   [nir_op_ior] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         3,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         5,
         2,
         3,
         6,
         3,
         4,
         7,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 8,
      .table = (const uint16_t []) {
      
         32,
         33,
         67,
         68,
         69,
         67,
         68,
         69,
         33,
         33,
         70,
         71,
         72,
         88,
         89,
         90,
         67,
         70,
         67,
         73,
         74,
         67,
         73,
         74,
         68,
         71,
         73,
         68,
         75,
         73,
         68,
         75,
         69,
         72,
         74,
         75,
         69,
         74,
         75,
         69,
         67,
         88,
         67,
         73,
         74,
         67,
         73,
         74,
         68,
         89,
         73,
         68,
         75,
         73,
         68,
         75,
         69,
         90,
         74,
         75,
         69,
         74,
         75,
         69,
      },
   },
   [nir_op_ixor] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         0,
         0,
         3,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         2,
         5,
         3,
         3,
         6,
         4,
         4,
         7,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 8,
      .table = (const uint16_t []) {
      
         34,
         35,
         76,
         77,
         78,
         76,
         77,
         78,
         35,
         35,
         79,
         80,
         81,
         91,
         92,
         93,
         76,
         79,
         76,
         82,
         83,
         76,
         82,
         83,
         77,
         80,
         82,
         77,
         84,
         82,
         77,
         84,
         78,
         81,
         83,
         84,
         78,
         83,
         84,
         78,
         76,
         91,
         76,
         82,
         83,
         76,
         82,
         83,
         77,
         92,
         82,
         77,
         84,
         82,
         77,
         84,
         78,
         93,
         83,
         84,
         78,
         83,
         84,
         78,
      },
   },
   [nir_op_ushr] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         3,
         0,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         2,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         3,
         3,
         3,
         0,
         0,
         0,
         0,
         0,
         0,
         4,
         4,
         4,
         0,
         0,
         0,
         2,
         2,
         2,
         3,
         3,
         3,
         4,
         4,
         4,
      },
      
      .num_filtered_states = 5,
      .table = (const uint16_t []) {
      
         36,
         36,
         36,
         36,
         36,
         36,
         36,
         36,
         36,
         36,
         36,
         52,
         36,
         36,
         36,
         36,
         53,
         36,
         36,
         36,
         36,
         54,
         36,
         36,
         36,
      },
   },
   [nir_op_ishr] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         0,
         0,
         3,
         0,
         4,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         2,
         2,
         2,
         0,
         0,
         0,
         0,
         0,
         0,
         3,
         3,
         3,
         0,
         0,
         0,
         0,
         0,
         0,
         4,
         4,
         4,
         0,
         0,
         0,
         2,
         2,
         2,
         3,
         3,
         3,
         4,
         4,
         4,
      },
      
      .num_filtered_states = 5,
      .table = (const uint16_t []) {
      
         37,
         37,
         37,
         37,
         37,
         37,
         37,
         37,
         37,
         37,
         37,
         55,
         37,
         37,
         37,
         37,
         56,
         37,
         37,
         37,
         37,
         57,
         37,
         37,
         37,
      },
   },
   [nir_op_urol] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         38,
      },
   },
   [nir_op_uror] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         39,
      },
   },
   [nir_op_imul_high] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         40,
      },
   },
   [nir_op_umul_high] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         41,
      },
   },
   [nir_op_fpow] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         42,
      },
   },
   [nir_op_ldexp] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         43,
      },
   },
};

/* Mapping from state index to offset in transforms (0 being no transforms) */
static const uint16_t bifrost_nir_lower_algebraic_late_transform_offsets[] = {
   0,
   0,
   1,
   0,
   3,
   0,
   5,
   7,
   9,
   11,
   13,
   18,
   23,
   25,
   30,
   35,
   37,
   39,
   41,
   43,
   47,
   49,
   51,
   53,
   55,
   57,
   59,
   0,
   68,
   85,
   87,
   89,
   91,
   93,
   95,
   97,
   99,
   101,
   103,
   105,
   107,
   111,
   115,
   117,
   119,
   122,
   124,
   126,
   143,
   176,
   179,
   182,
   185,
   188,
   191,
   194,
   197,
   200,
   203,
   206,
   209,
   212,
   215,
   218,
   221,
   225,
   229,
   233,
   236,
   239,
   242,
   245,
   248,
   251,
   255,
   259,
   263,
   266,
   269,
   272,
   275,
   278,
   281,
   285,
   289,
   293,
   297,
   301,
   305,
   309,
   313,
   317,
   321,
   325,
};

static const nir_algebraic_table bifrost_nir_lower_algebraic_late_table = {
   .transforms = bifrost_nir_lower_algebraic_late_transforms,
   .transform_offsets = bifrost_nir_lower_algebraic_late_transform_offsets,
   .pass_op_table = bifrost_nir_lower_algebraic_late_pass_op_table,
   .values = bifrost_nir_lower_algebraic_late_values,
   .expression_cond = bifrost_nir_lower_algebraic_late_expression_cond,
   .variable_cond = NULL,
};

bool
bifrost_nir_lower_algebraic_late(
   nir_shader *shader
   , unsigned  gpu_arch
   , bool  is_kraid
) {
   bool progress = false;
   bool condition_flags[3];
   const nir_shader_compiler_options *options = shader->options;
   const shader_info *info = &shader->info;
   (void) options;
   (void) info;

   STATIC_ASSERT(393 == ARRAY_SIZE(bifrost_nir_lower_algebraic_late_values));
   condition_flags[0] = true;
   condition_flags[1] = gpu_arch >= 11;
   condition_flags[2] = is_kraid;

   nir_foreach_function_impl(impl, shader) {
     progress |= nir_algebraic_impl(impl, condition_flags, &bifrost_nir_lower_algebraic_late_table);
   }

   return progress;
}

